Mutable Instruments' project template, makefile, and libraries for STM32F
projects.

See LICENSE for licensing information.

More to come!